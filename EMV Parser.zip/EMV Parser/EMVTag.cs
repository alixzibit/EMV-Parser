﻿namespace EMV_Parser
{
    public class EMVTag
    {
        public string TagName { get; set; }
        public string TagValue { get; set; }
    }
}